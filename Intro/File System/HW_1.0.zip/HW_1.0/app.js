const http = require('http');
const fs = require('fs');

http.createServer((req,res)=>{
    // TODOO
}).listen(1337, ()=>{
    console.log(`The Server Is Running On Port 1337`)
});


